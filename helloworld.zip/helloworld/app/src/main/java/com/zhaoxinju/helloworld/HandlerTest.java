package com.zhaoxinju.helloworld;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HandlerTest extends AppCompatActivity {
    private int run_cnt = 0;
    private Message message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_handler_test);

        final TextView textView = findViewById(R.id.run_handler_disp);

        Handler handler= new Handler() {
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                /*处理消息*/
                textView.setText("run" + msg.what);
            }
        };

        Button btn = findViewById(R.id.run_handler);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
//                        textView.setText("run 2");  /*直接更新主线程的TextView，将会引起错误*/
                        handler.sendEmptyMessage(run_cnt ++);    /*发送空消息*/
                    }
                });
                thread.start();
            }
        });

        LooperTest thread = new LooperTest();   /*创建一个线程*/
        thread.start();
    }
}