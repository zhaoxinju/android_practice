package com.zhaoxinju.helloworld;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class TervDevAdapter extends BaseAdapter {
    List<TervDev> tervDevs;
    Context context;

    public TervDevAdapter(Context context, List<TervDev> tervDevs) {
        this.context = context;
        this.tervDevs = tervDevs;
    }

    /*获取数据集的数量*/
    @Override
    public int getCount() {
        return this.tervDevs.size();
    }

    /*返回指定position的item*/
    @Override
    public Object getItem(int i) {
        return this.tervDevs.get(i);
    }

    /*获取item的下标*/
    @Override
    public long getItemId(int i) {
        return i;
    }

    /*获取item的布局*/
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        TervDev tervDev = tervDevs.get(i);
        View convertView;
        ViewHolder viewHolder;
        if (view == null)
        {
            convertView = View.inflate(context,R.layout.item_dev,null);
            viewHolder = new ViewHolder();
            viewHolder.locView = convertView.findViewById(R.id.dev_loc);
            viewHolder.addrView = convertView.findViewById(R.id.dev_addr);
            convertView.setTag(viewHolder);
        }
        else
        {
            convertView = view;
            viewHolder = (ViewHolder)view.getTag();
        }

        viewHolder.locView.setText(tervDev.getLoc());
        viewHolder.addrView.setText(tervDev.getAddr());

        return convertView;
    }

    /*静态内部类*/
    static class ViewHolder{
        TextView addrView;
        TextView locView;
    }
}
