package com.zhaoxinju.helloworld;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DBOpenHelper extends SQLiteOpenHelper {
    /*定义创建数据表的语句               创建命令       表名称   字段  字段类型 主键    自动编号，           这两个字段默认类型*/
    final String CREATE_TABLE_SQL = "create table tb_dict (_id integer primary key autoincrement, word, detail)";
    public DBOpenHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_SQL);   /*创建单词数据表*/
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        Log.i("更新","old " + i +"to" + i1);
    }
}
