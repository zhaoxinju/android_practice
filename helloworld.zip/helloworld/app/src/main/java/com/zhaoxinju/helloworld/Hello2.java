package com.zhaoxinju.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Hello2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hello2);

//        Intent intent=getIntent();
//        Bundle bundle=intent.getExtras();   /*获取bundle*/
//        String msg = bundle.getString("message");   /*获取Bundle中的相应字段*/
//        TextView textv = findViewById(R.id.disp_text);
//        textv.setText(msg);     /*获取失败会导致程序崩溃*/


        Button btn = findViewById(R.id.close_button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*返回值给上一个Activity*/
                Intent intent=getIntent();
                Bundle bundle = new Bundle();   /*建立一个Bundle*/
                bundle.putString("message2", "this is what you want");    /*写入数据*/
                intent.putExtras(bundle);
                setResult(0x11, intent);    /*resultCode与requestCode一般相同*/
                finish();
            }
        });
    }
}
