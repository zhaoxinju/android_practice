package com.zhaoxinju.helloworld;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn_hello = findViewById(R.id.hello_button);
        TextView txt_hello = findViewById(R.id.hello);

        btn_hello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*添加要执行的代码*/
                txt_hello.setText("yes");

                Intent intent = new Intent(MainActivity.this, TcpTest.class);
                startActivity(intent);
            }
        });
    }

    public void myClick(View view){
        /*添加要执行的代码*/
        TextView txt_hello = findViewById(R.id.hello);
        txt_hello.setText("no");

        /*利用Bundle交换数据*/
        String msg = ((EditText)findViewById(R.id.msg_edit)).getText().toString();
        Intent intent = new Intent(MainActivity.this, Hello2.class);
        Bundle bundle = new Bundle();   /*创建Bundle*/
        bundle.putCharSequence("message",msg);  /*字符串放入Bundle*/
        intent.putExtras(bundle);   /*Bundle写入intent*/
//        startActivity(intent);  /*启动Activity*/
        startActivityForResult(intent, 0x11);
    }

    /*重写onActivityResult，接收返回值*/
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        /*判断请求码与结果码*/
        if ((requestCode == 0x11) && (resultCode == 0x11))
        {
            Bundle bundle = data.getExtras();   /*从Bundle获取数据*/
            String res = bundle.getString("message2");  /*找到需要的字段*/
            TextView txt_hello = findViewById(R.id.hello);
            txt_hello.setText(res);
        }
    }

}