package com.zhaoxinju.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

/*在listview中显示可以下拉的、重复格式的自定义界面
* 1.定义对象TervDev
* 2.创建adapter，创建自定义样式，在adapter中将TervDev对象的数据赋值给控件
* 3.设置adapter
* */
public class ListViewTest extends AppCompatActivity {

    private List<TervDev> tervDevs = new ArrayList<>();

    private String [] data = {"福建霞浦","云南苍岭","云南元谋","西藏当雄","广东茂名"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view_test);

        initView();
    }

    private void initView() {
        /*adapter，让数据和listView结合起来，起到桥梁的作用*/
        /*ArrayAdapter，不能自定义布局*/
//        ArrayAdapter<String> tervDevAdapter= new ArrayAdapter<String> (
//                ListViewTest.this, android.R.layout.simple_list_item_1,data);

        /*BaseAdapter，自定义布局*/
        initData();
        TervDevAdapter tervDevAdapter = new TervDevAdapter(ListViewTest.this, tervDevs);

        ListView listView = findViewById(R.id.listv);
        listView.setAdapter(tervDevAdapter);
    }

    private void initData() {
        tervDevs.add(new TervDev("福建霞浦", "10200006"));
        tervDevs.add(new TervDev("云南苍岭", "10200009"));
        tervDevs.add(new TervDev("云南元谋", "10200011"));
        tervDevs.add(new TervDev("西藏当雄", "10200010"));
        tervDevs.add(new TervDev("广东茂名", "10200012"));
    }
}