package com.zhaoxinju.helloworld;

public class TervDev {
    private String loc;
    private String addr;

    public TervDev(String loc, String addr) {
        this.loc = loc;
        this.addr = addr;
    }

    public String getLoc() {
        return loc;
    }

    public String getAddr() {
        return addr;
    }
}
