package com.zhaoxinju.helloworld;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import androidx.annotation.NonNull;

public class LooperTest extends Thread{
    public Handler handler;

    @Override
    public void run() {
        super.run();
        Looper.prepare();   /*初始化looper对象*/
        handler = new Handler() {
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                Log.i("looper", String.valueOf(msg.what));
            }
        };

        Message message = handler.obtainMessage();  /*获取Message*/
        message.what = 0x07;    /*设置消息代码*/
        handler.sendMessage(message);   /*发送消息*/
        Looper.loop();  /*启动looper*/
    }
}
