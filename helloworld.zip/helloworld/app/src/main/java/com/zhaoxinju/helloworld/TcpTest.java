package com.zhaoxinju.helloworld;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class TcpTest extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tcp_test);

        EditText et_ip = findViewById(R.id.et_ip);
        EditText et_port = findViewById(R.id.et_port);
        Button button_con = findViewById(R.id.btn_tcp_connect);
        Button button_dis = findViewById(R.id.btn_tcp_disconnect);

        button_con.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*TODO 檢查ip或port是否为空*/
                TcpClient.getInstance().connect(et_ip.getText().toString(), Integer.parseInt(et_port.getText().toString()));
                TcpClient.getInstance().setOnDataReceiveListener(dataReceiveListener);
            }
        });

        button_dis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TcpClient.getInstance().disconnect();
                dataReceiveListener = null;
            }
        });
    }

    private TcpClient.OnDataReceiveListener dataReceiveListener = new TcpClient.OnDataReceiveListener() {
        @Override
        public void onConnectSuccess() {
            Log.i("TcpTest","onDataReceive connect success");
            Toast.makeText(TcpTest.this, "连接到服务器", Toast.LENGTH_LONG).show();
        }

        @Override
        public void onConnectFail() {
            Log.e("TcpTest","onDataReceive connect fail");
            Toast.makeText(TcpTest.this, "连接断开", Toast.LENGTH_LONG).show();
            TcpTest.this.finish();
        }

        @Override
        public void onDataReceive(byte[] buffer, int size, int requestCode) {
            /*接收数据的解析*/
        }

        //发送使用
        // TcpClient.getInstance().sendByteCmd(frame_send,1001);
    };

    @Override
    protected void onDestroy() {
        TcpClient.getInstance().disconnect();
        dataReceiveListener = null;
        super.onDestroy();
    }
}