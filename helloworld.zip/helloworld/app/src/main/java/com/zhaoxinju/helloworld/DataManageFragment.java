package com.zhaoxinju.helloworld;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link DataManageFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class DataManageFragment extends Fragment {
    private DBOpenHelper dbOpenHelper;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public DataManageFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment DataManageFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static DataManageFragment newInstance(String param1, String param2) {
        DataManageFragment fragment = new DataManageFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_data_manage, container, false);

        final EditText etName = view.findViewById(R.id.class_name);
        final TextView txtName = view.findViewById(R.id.read_name);

        /*实例化对象，将创建数据库*/
        dbOpenHelper = new DBOpenHelper(view.getContext(), "db_dict", null, 1);

        /*插入*/
        Button btn_add = view.findViewById(R.id.sq_add);
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String word = etName.getText().toString();
                String interpret = "名字";
                insertData(dbOpenHelper.getReadableDatabase(), word, interpret);
            }
        });

        /*查询*/
        Button btn_read = view.findViewById(R.id.sq_read);
        btn_read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String key = etName.getText().toString();
                /*查询表tb_dict中word==key的数据项*/
                Cursor cursor = dbOpenHelper.getReadableDatabase().query("tb_dict", null, "word=?",new String[]{key},
                        null, null, null);
                /*创建ArrayList，保存查询结果*/
                ArrayList<Map<String, String>> resultlist = new ArrayList<Map<String, String>>();
                while (cursor.moveToNext()) {
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("word", cursor.getString(1));
                    map.put("interpret", cursor.getString(2));
                    resultlist.add(map);
                }
                if (resultlist == null || resultlist.size() == 0) {
                    Toast.makeText(view.getContext(), "没有相关记录", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(view.getContext(), "查询到记录", Toast.LENGTH_LONG).show();
                }
            }
        });

        /*删除*/
        Button btn_del = view.findViewById(R.id.sq_del);
        btn_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        return view;
    }

    /*插入方法，两个String对应两个字段*/
    private void insertData (SQLiteDatabase sql_db, String word, String interpret) {
        ContentValues values = new ContentValues();
        values.put("word", word);   /*第一个字段，保存单词*/
        values.put("detail", interpret);    /*第二个字段，保存解释*/
        sql_db.insert("tb_dict", null, values);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (dbOpenHelper != null) {
            dbOpenHelper.close();
        }
    }
}